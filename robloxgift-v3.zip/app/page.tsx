 "use client";

import { useState } from "react";

type RobloxUser = { id: number; name: string; displayName: string; avatarUrl: string };

export default function Home() {
  const [username, setUsername] = useState("");
  const [user, setUser] = useState<RobloxUser | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showGiftChoice, setShowGiftChoice] = useState(false);
  const [giftType, setGiftType] = useState<"Pass Permainan" | "Uang" | null>(null);

  async function findUser() {
    if (!username.trim()) { setError("Masukkan username Roblox terlebih dahulu."); return; }
    setLoading(true); setError(""); setUser(null); setShowGiftChoice(false); setGiftType(null);
    try {
      const response = await fetch("/api/roblox-user", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: username.trim() })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Username tidak ditemukan.");
      setUser(data);
      setShowGiftChoice(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal mencari username.");
    } finally { setLoading(false); }
  }

  return (
    <main className="site">
      <header className="topbar">
        <div className="brand"><span className="brandMark">rg</span><div><b>robloxgift</b><small>DDS GIFT CENTER</small></div></div>
        <div className="topRight"><span className="statusDot" /> STORE ONLINE <span className="avatarMini">R</span></div>
      </header>

      <section className="hero">
        <div className="crumb">Beranda <span>/</span> Toko <span>/</span> Drag Drive Simulator</div>
        <div className="heroCopy">
          <p className="eyebrow">DRAG DRIVE SIMULATOR</p>
          <h1>Gift Center</h1>
          <p className="sub">Masukkan username Roblox untuk memilih jenis hadiah.</p>
        </div>
      </section>

      <section className="mainCard">
        <div className="searchHeader">
          <div><span className="giftIcon">🎁</span><div><h2>Kirim Hadiah</h2><p>Cari akun Roblox penerima terlebih dahulu.</p></div></div>
          <span className="secureLabel">ROBLOX USER LOOKUP</span>
        </div>
        <div className="lookupRow">
          {user ? <img className="avatarLarge" src={user.avatarUrl} alt={`Avatar ${user.name}`} /> : <div className="avatarPlaceholder">?</div>}
          <div className="lookupInput">
            <label htmlFor="username">USERNAME ROBLOX</label>
            <input id="username" value={username} onChange={e => { setUsername(e.target.value); setUser(null); setShowGiftChoice(false); setGiftType(null); setError(""); }} onKeyDown={e => { if (e.key === "Enter") findUser(); }} placeholder="Masukkan username Roblox..." />
          </div>
          <button className="searchButton" onClick={findUser} disabled={loading}>{loading ? "Mencari..." : "Cari akun"}</button>
        </div>
        {error && <p className="errorMessage">{error}</p>}
        {user && <div className="foundUser">
          <div className="foundText"><span className="foundDot">✓</span><div><b>{user.displayName}</b><small>@{user.name} · ID {user.id}</small></div></div>
          {giftType && <div className="selectedType">Jenis hadiah dipilih: <b>{giftType}</b><button onClick={() => setShowGiftChoice(true)}>Ubah</button></div>}
        </div>}
        {!user && !error && <div className="emptyLookup"><span>◉</span><b>Belum ada akun yang dipilih</b><small>Avatar dan pilihan hadiah akan muncul setelah username ditemukan.</small></div>}
      </section>

      {showGiftChoice && user && <div className="modalBackdrop" role="presentation" onClick={() => setShowGiftChoice(false)}>
        <div className="giftModal" role="dialog" aria-modal="true" onClick={e => e.stopPropagation()}>
          <div className="giftModalTitle">Gift to: {user.name}</div>
          <div className="giftButtons">
            <button className="passButton" onClick={() => { setGiftType("Pass Permainan"); setShowGiftChoice(false); }}>PASS PERMAINAN</button>
            <button className="moneyButton" onClick={() => { setGiftType("Uang"); setShowGiftChoice(false); }}>UANG</button>
          </div>
          <button className="cancelButton" onClick={() => { setShowGiftChoice(false); setGiftType(null); }}>BATAL</button>
        </div>
      </div>}

      <footer><span>robloxgift</span><span>Fan-made interface • Tidak berafiliasi dengan Roblox atau Drag Drive Simulator.</span></footer>
    </main>
  );
}
