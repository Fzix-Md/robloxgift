import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "robloxgift | DDS Gift Store",
  description: "Gift store interface for Drag Drive Simulator.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
