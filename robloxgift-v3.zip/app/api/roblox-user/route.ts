import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const { username } = await request.json();
    if (typeof username !== "string" || !username.trim()) {
      return NextResponse.json({ error: "Username harus diisi." }, { status: 400 });
    }

    const lookup = await fetch("https://users.roblox.com/v1/usernames/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ usernames: [username.trim()], excludeBannedUsers: false }),
      cache: "no-store"
    });
    if (!lookup.ok) return NextResponse.json({ error: "Layanan pencarian Roblox sedang tidak tersedia." }, { status: 502 });
    const result = await lookup.json();
    const account = result.data?.[0];
    if (!account) return NextResponse.json({ error: "Username Roblox tidak ditemukan." }, { status: 404 });

    const thumb = await fetch(
      `https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${account.id}&size=150x150&format=Png&isCircular=false`,
      { cache: "no-store" }
    );
    const thumbData = thumb.ok ? await thumb.json() : null;
    const avatarUrl = thumbData?.data?.[0]?.imageUrl || "";

    return NextResponse.json({
      id: account.id,
      name: account.name,
      displayName: account.displayName,
      avatarUrl
    });
  } catch {
    return NextResponse.json({ error: "Terjadi kesalahan saat mencari akun Roblox." }, { status: 500 });
  }
}
